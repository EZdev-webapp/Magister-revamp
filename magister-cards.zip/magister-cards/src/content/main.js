// Phase 1: prove we load, find the grid, and can count grades. Read-only.
(() => {
  const C = MC.config;
  let host = null, label = null, lastMsg = '';

  function showBadge(text) {
    if (!host) {
      host = document.createElement('div');
      const sh = host.attachShadow({ mode: 'closed' });
      sh.innerHTML = `<style>
        div{position:fixed;right:16px;bottom:16px;z-index:2147483647;
        background:#111;color:#fff;font:13px system-ui,sans-serif;
        padding:8px 12px;border-radius:8px;opacity:.9}</style><div></div>`;
      label = sh.querySelector('div');
      document.documentElement.appendChild(host);
    }
    label.textContent = text;
  }

  function removeBadge() { host?.remove(); host = null; label = null; }

  function isTestGrade(span) {
    if (C.skipClasses.some(c => span.classList.contains(c))) return false;
    const idLabel = (span.id.split('_')[1] || '');
    if (idLabel.startsWith(C.reportIdPrefix)) return false;
    return span.title.trim() !== '';
  }

  function scan() {
    if (!location.hash.startsWith(C.routeHash)) { removeBadge(); return; }
    const rows = [...document.querySelectorAll(C.selectors.row)]
      .filter(r => r.querySelector(C.selectors.grade));
    if (!rows.length) { showBadge('Magister Cards: waiting for grade grid…'); return; }
    const headers = document.querySelectorAll(C.selectors.headerLabel).length;
    let grades = 0;
    rows.forEach(r => r.querySelectorAll(C.selectors.grade).forEach(s => { if (isTestGrade(s)) grades++; }));
    const msg = `Magister Cards loaded: ${rows.length} subjects, ${headers} headers, ${grades} grades`;
    if (msg !== lastMsg) { console.log('[MC]', msg); lastMsg = msg; }
    showBadge(msg);
  }

  let t;
  const schedule = () => { clearTimeout(t); t = setTimeout(scan, C.debounceMs); };
  new MutationObserver(schedule).observe(document.body, { childList: true, subtree: true });
  window.addEventListener('hashchange', schedule);
  schedule();
})();
