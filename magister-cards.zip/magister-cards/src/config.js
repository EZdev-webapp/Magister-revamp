// All Magister-specific knowledge lives here, so DOM changes = one-file fix.
globalThis.MC = globalThis.MC || {};
MC.config = {
  routeHash: '#/cijfers/cijferoverzicht',
  debounceMs: 300,
  selectors: {
    headerLabel: 'span.gradeHeader',
    row: 'tr[data-uid]',
    grade: 'span.grade'
  },
  skipClasses: ['empty', 'gemiddeldecolumn'],
  reportIdPrefix: 'Rap' // ids look like "ne_Rap 3_395"
};
